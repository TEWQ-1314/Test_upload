#include<stdio.h>
int main()
{
	int y = 3, x = 3, z = 1;
	printf("结果为：\n%d,%d,%d\n", (++x, y++), z + x + y + 2);
	printf("%d,%d",x,y);
	return 0;
}