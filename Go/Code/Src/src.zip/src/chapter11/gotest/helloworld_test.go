package gotest

import (
	"testing"
)

func TestHelloWorld(t *testing.T) {
	t.Log("hello world")
}
