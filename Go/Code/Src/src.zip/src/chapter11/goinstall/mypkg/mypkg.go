package mypkg

import "fmt"

func CustomPkgFunc() {
	fmt.Println("call CustomPkgFunc")
}
