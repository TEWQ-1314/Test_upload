package main

import (
	"chapter11/goinstall/mypkg"
	"fmt"
)

func main() {

	mypkg.CustomPkgFunc()

	fmt.Println("hello world")
}
