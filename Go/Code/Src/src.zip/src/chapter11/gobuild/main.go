package main

import (
	"fmt"
)

func main() {

	// 同包的函数
	pkgFunc()

	fmt.Println("hello world")
}
