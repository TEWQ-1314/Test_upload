package main

import "fmt"

func pkgFunc() {
	fmt.Println("call pkgFunc")
}
