package main

import "chapter08/pkginit/pkg1"

func main() {

	pkg1.ExecPkg1()
}
