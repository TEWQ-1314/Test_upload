package pkg2

import "fmt"

func ExecPkg2() {
	fmt.Println("ExecPkg2")
}

func init() {
	fmt.Println("pkg2 init")
}
