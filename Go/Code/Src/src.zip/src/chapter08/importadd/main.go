package main

import (
	renameLib "chapter08/importadd/mylib"
	"fmt"
)

func main() {
	fmt.Println(renameLib.Add(1, 2))
}
