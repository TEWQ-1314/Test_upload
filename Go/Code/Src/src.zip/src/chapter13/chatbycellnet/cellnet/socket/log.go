package socket

import (
	"github.com/davyxu/golog"
)

var log = golog.New("socket")
